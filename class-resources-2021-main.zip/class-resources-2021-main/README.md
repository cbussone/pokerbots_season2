# class-resources-2021
Contains Pokerbots course resources for IAP 2021
